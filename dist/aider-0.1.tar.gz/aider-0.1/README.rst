# Utils

	generic utilities for developer to use in reguler programming.
